var name = prompt("Enter Your Name");
var welcome = document.getElementById("welcome");
welcome.innerHTML = "Welcome " + " " + name + "!";